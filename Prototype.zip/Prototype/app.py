import streamlit as st
import pandas as pd
import torch
import numpy as np
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from lime.lime_text import LimeTextExplainer

st.set_page_config(page_title="Fake News Detector", layout="centered")

@st.cache_resource
def load_model():
    model = AutoModelForSequenceClassification.from_pretrained("./fake_news_bert_model")
    tokenizer = AutoTokenizer.from_pretrained("./fake_news_bert_model")
    model.eval()
    return model, tokenizer

@st.cache_data
def load_data():
    return pd.read_csv("combined_fake_real_news.csv")

model, tokenizer = load_model()
df = load_data()

# === Prediction function ===
def predict(text, context):
    combined = text + " " + " ".join(context)
    inputs = tokenizer(combined, return_tensors="pt", truncation=True, padding=True, max_length=512)
    with torch.no_grad():
        logits = model(**inputs).logits
        probs = torch.softmax(logits, dim=1).squeeze().numpy()
        pred = np.argmax(probs)
    return ("REAL" if pred == 1 else "FAKE"), probs

# === LIME Explanation ===
explainer = LimeTextExplainer(class_names=["FAKE", "REAL"])

def explain(text, context):
    combined = text + " " + " ".join(context)
    def predictor(texts):
        predictions = []
        for t in texts:
            inputs = tokenizer(t, return_tensors="pt", truncation=True, padding=True, max_length=512)
            with torch.no_grad():
                logits = model(**inputs).logits
                probs = torch.softmax(logits, dim=1).squeeze().numpy()
                predictions.append(probs)
        return np.array(predictions)
    exp = explainer.explain_instance(combined, predictor, num_features=5)
    return exp.as_list()

# === Streamlit UI ===
st.title(" Fake News Detection Chatbot")
st.markdown("Paste a news article or claim below to verify if it's **REAL** or **FAKE**.")

text = st.text_area("Enter your news snippet:", height=200)

if st.button("Check News"):
    with st.spinner("Analyzing..."):
        if not text.strip():
            st.warning("Please enter a news statement.")
        else:
            context = df.sample(2)['content'].tolist()
            verdict, probs = predict(text, context)
            st.success(f" Verdict: **{verdict}**")
            st.write(f"**Confidence** → REAL: {probs[1]:.2f}, FAKE: {probs[0]:.2f}")

            st.subheader(" Explanation (LIME):")
            for word, weight in explain(text, context):
                st.markdown(f"- `{word}`: `{weight:.2f}`")
