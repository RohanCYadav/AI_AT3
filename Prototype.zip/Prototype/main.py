import os
import pandas as pd
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from transformers import BertTokenizerFast, BertForSequenceClassification
from torch.optim import AdamW
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns

# === CONFIG ===
EPOCHS = 4
PATIENCE = 1
BATCH_SIZE = 16
MODEL_DIR = "./fake_news_bert_model"
os.makedirs(MODEL_DIR, exist_ok=True)  # ✅ Ensure it exists before saving

#  Use GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Load full dataset
df = pd.read_csv("combined_fake_real_news.csv")

# Shuffle entire dataset to randomize rows before splitting
df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)

# Stratified split to preserve balance between FAKE (0) and REAL (1)
train_df, val_df = train_test_split(
    df,
    test_size=0.2,
    random_state=42,
    stratify=df["label"]
)

train_df = train_df.sample(n=8000, random_state=42)
val_df = val_df.sample(n=2000, random_state=42)

# Extract lists for tokenizer
train_texts = train_df["content"].tolist()
train_labels = train_df["label"].tolist()
val_texts = val_df["content"].tolist()
val_labels = val_df["label"].tolist()

#  Tokenize
tokenizer = BertTokenizerFast.from_pretrained("bert-base-uncased")
train_encodings = tokenizer(list(train_texts), truncation=True, padding=True, max_length=512)
val_encodings = tokenizer(list(val_texts), truncation=True, padding=True, max_length=512)

class NewsDataset(Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels
    def __getitem__(self, idx):
        return {
            "input_ids": torch.tensor(self.encodings["input_ids"][idx]),
            "attention_mask": torch.tensor(self.encodings["attention_mask"][idx]),
            "labels": torch.tensor(self.labels[idx])
        }
    def __len__(self):
        return len(self.labels)

train_dataset = NewsDataset(train_encodings, list(train_labels))
val_dataset = NewsDataset(val_encodings, list(val_labels))

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE)

#  Model
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)
model.to(device)

optimizer = AdamW(model.parameters(), lr=2e-5)

# === TRAINING LOOP ===
best_val_loss = float("inf")
patience_counter = 0
history = {"train_loss": [], "val_loss": []}

for epoch in range(EPOCHS):
    print(f"\n Epoch {epoch + 1}/{EPOCHS}")

    model.train()
    train_loss = 0
    for batch in tqdm(train_loader):
        optimizer.zero_grad()
        inputs = {k: v.to(device) for k, v in batch.items()}
        outputs = model(**inputs)
        loss = outputs.loss
        train_loss += loss.item()
        loss.backward()
        optimizer.step()
    avg_train_loss = train_loss / len(train_loader)

    model.eval()
    val_loss = 0
    with torch.no_grad():
        for batch in val_loader:
            inputs = {k: v.to(device) for k, v in batch.items()}
            outputs = model(**inputs)
            val_loss += outputs.loss.item()
    avg_val_loss = val_loss / len(val_loader)

    print(f" Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f}")
    print(f"[EarlyStopping] Best Val Loss: {best_val_loss:.6f} | Current Val Loss: {avg_val_loss:.6f} | Counter: {patience_counter}/{PATIENCE}")

    history["train_loss"].append(avg_train_loss)
    history["val_loss"].append(avg_val_loss)

    # === EARLY STOPPING ===
    if avg_val_loss < best_val_loss:
        best_val_loss = avg_val_loss
        patience_counter = 0
        torch.save(model.state_dict(), os.path.join(MODEL_DIR, "best_model.pt"))
    else:
        patience_counter += 1
        if patience_counter >= PATIENCE:
            print(" Early stopping triggered.")
            break

# === EVALUATION ===
model.load_state_dict(torch.load(os.path.join(MODEL_DIR, "best_model.pt")))
model.eval()

all_preds, all_labels = [], []
with torch.no_grad():
    for batch in val_loader:
        inputs = {k: v.to(device) for k, v in batch.items()}
        logits = model(**inputs).logits
        preds = torch.argmax(logits, dim=1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(inputs["labels"].cpu().numpy())

print("\n Classification Report:")
print(classification_report(all_labels, all_preds))

# === SAVE MODEL + TOKENIZER ===
model.save_pretrained(MODEL_DIR)
tokenizer.save_pretrained(MODEL_DIR)
print(f" Model and tokenizer saved to {MODEL_DIR}")

# === SAVE TRAINING LOG ===
pd.DataFrame(history).to_csv("training_log.csv", index=False)
print(" Training log saved to training_log.csv")

# === PLOT LOSS CURVE ===
plt.figure(figsize=(8, 5))
sns.lineplot(x=range(1, len(history["train_loss"]) + 1), y=history["train_loss"], label="Train Loss")
sns.lineplot(x=range(1, len(history["val_loss"]) + 1), y=history["val_loss"], label="Val Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Loss Curve")
plt.legend()
plt.grid(True)
plt.savefig("loss_curve.png")
plt.show()