import transformers
print("Transformers version:", transformers.__version__)
print("Transformers location:", transformers.__file__)

from transformers import TrainingArguments
TrainingArguments(output_dir="./out", evaluation_strategy="epoch")
print("✅ TrainingArguments is working correctly.")